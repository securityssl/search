<?php
session_start();
require("inc/config.php");
$is_https = "//";
$sid = $_SESSION['logged'];
$sql_select2 = "SELECT * FROM users WHERE hash = '$sid'";
$result2 = mysql_query($sql_select2);
$row = mysql_fetch_array($result2);
if($row)
{
$user_id = $row['id'];
$balance = $row['balance'];
$ava = $row['ava'];
$login = $row['login'];
}
$select = "SELECT * FROM tovars";
$all_tovars = mysql_query($select);
$pur = "SELECT * FROM purchases WHERE user_id = '$user_id'";
$all_purchases = mysql_query($pur);
$data = date("d.m.Y");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$sitename?>.<?=$sitedomen?> &raquo; Магазин скриптов</title>
<meta property="og:image" content="/img/logoog.png" />
<meta name="description" content="Здесь вы можете купить готовый сайт для заработка или других целей. Магазин скриптов KotDev.fun предоставляет огромный выбор качественных сайтов." />
<meta name="keywords" content="создание сайта, создать сайт самому, скрипт, скачать скрипты бесплатно, скачать скрипты, скрипты для сайта, скрипты сайтов, движки сайтов, Интернет-магазин, skript, opcash, денежные кейсы, кейсы с деньгами, скрипты буксов, буксы, Хайпы, экономический игры, азартные игры, скрипт интернет магазина, магазин аккаунтов, скрипты рулеток, cosmocard, jetcash, spinmoney, bangcash, armycash, luxacesh, cash, рулетки cs:go, скрипт cs:go рулетки, заработок в сети, заработок в интернете, софт для веб-мастера, взлом рулетки с денежными кейсы, взлом opcash, создание сайта под заказ, создать сайт, заказать сайт, купить сайт, купить opcash, как установить сайт, установка скрипты, как установить скрипт, Купить рулетку, скрипт кейсов, купить web скрипт, купить сайт, рулетка варфейс, рулетка warface, заказать рулетку, купить недорого web скрипт, купить nvuti, скрипт nvuti,купить веб скрипт,магазин скриптов, купить скрипт рулетки,магазин скриптов рулеток,купить рулетку сайт, nvuti," />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link href="/img/logo.png" rel="icon" type="image/png" />
<link rel="stylesheet" href="/css/style.css">
<link rel="stylesheet" href="/css/toastr.css">
<script src="https://kit.fontawesome.com/6cce539f85.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" crossorigin="anonymous"></script>
<script src="//ulogin.ru/js/ulogin.js"></script>
<script src="../js/jquery-latest.min.js"></script>
<script type="text/javascript" src="https://vk.com/js/api/openapi.js?167"></script>
<style>
    tr {
            white-space: nowrap;
        }
        @media (max-width:1575.98px) {
    .table-responsive-sm {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: -ms-autohiding-scrollbar
    }
</style>
</head>
<body>
<div class="loaderArea">
		<div id="loader"></div>
	</div>    
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">
    <img src="/img/logo.png" width="30" height="30" class="d-inline-block align-top" alt="" title="Котик">
    <?=$sitename?>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Главная</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/" data-toggle="modal" data-target="#contact">Контакты</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/" data-toggle="modal" data-target="#garant">Гарантии</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="<?=$reviews?>" target="_blank">Отзывы</a>
      </li>
      <?php
      if(!$_SESSION['logged']) { ?>
      <li class="nav-item">
        <a id="uLogin" data-ulogin="display=buttons;fields=photo_big,first_name,last_name;mobilebuttons=0;redirect_uri=<?=$is_https?><?=$_SERVER['HTTP_HOST']?>/vklogin.php;" class="nav-link" href="#" ><span data-uloginbutton="vkontakte">Авторизоваться</span></a>
      </li>
      <?php } else { ?>
      <li class="nav-item">
          <!-- <img src="<?=$ava?>" style="width:18px; height:18px; border-radius:999px; display:inline-block;">  -->
       <a class="nav-link palka" style="display:inline-block;cursor:pointer;">|</a>
       </li>
       <li class="nav-item">
        <a class="nav-link" href="#" style="display:inline-block;cursor:pointer;"><?=$login?></a>
        </li>
        <li class="nav-item">
       <a class="nav-link" style="display:inline-block; cursor:pointer;">Баланс: <span id="balance"><?=$balance?></span> <i class="fa fa-rub"></i></a>
       </li>
       <li class="nav-item">
       <a class="nav-link" style="display:inline-block;cursor:pointer;" data-toggle="modal" data-target="#deposit">Пополнить</a>
      </li>
      <li class="nav-item">
       <a class="nav-link" style="display:inline-block;cursor:pointer;" data-toggle="modal" data-target="#purchases">Мои покупки</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/logout.php" style="cursor:pointer;">Выйти</a>
      </li>
      <?php } ?>
    </ul>
    </div>
</nav>
<!-- NAVBAR END -->

<div class="container wrapper" style="min-height:376px;">
<div class="tab-content">
<div role="tabpanel" class="tab-pane fade in active show">
<div class="container">
<div class="row">
      <a class="btn badge-warning" style="color:#fff; cursor:default;margin-bottom:24px;width:100%; border-radius:30px; ">Самые низкие цены на скрипты!</a>
    <!-- ТОВАРЫ -->
         <?php 
while($row = mysql_fetch_array($all_tovars)) {
 
$id = $row['id'];
$name = $row['name'];
$desc = $row['sm_desc'];
$cost = $row['cost'];
$views = $row['views'];
$img = $row['img'];
$date_t = $row['date'];
if($date_t == $data) {
    $new = '<img src="/img/new.png" style="filter: hue-rotate(66deg)  ;width:20%;height:16%;position: absolute; right: -0.1%; top: 0px;">';
}
echo '<a class="game-box col-sm-3" href="#" title="'.$name.'" data-toggle="modal" data-target="#open_it" onclick="view('.$id.')">
<div class="thumbnail">
'.$new.'
<img src="'.$img.'" class="game-preview">
<div class="caption">
<p class="game-name">'.$name.'</p>
<p class="game-type"><img src="/img/icon.png" class="game-activate-icon"> '.$desc.'</p>
<p><span class="views" id="view'.$id.'">'.$views.' <i class="fa fa-eye" aria-hidden="true"></i></span><span class="price">'.$cost.' руб.</span></p>
</div>
</div>
</a>';

  }
?>
<!-- КОНЕЦ -->
    </div>
    </div>
    </div>
    </div>
    </div>
<div class="container-fluid footer-bg" style="margin-top:82px;">
<div class="container">
  
<footer>
   
<div class="row col-sm-12">
<div class="col-sm-5 foo-left-box">
<a class="navbar-brand" href="#">
    <img src="/img/logo.png" width="30" height="30" class="footer-cat -inline-block align-top" alt="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/">
    <?=$sitename?>
  </a>
<div class="nav-logo"><span class="footer-ava-text">&copy; 2019-2020 <?=$sitename?>.<?=$sitedomen?></span>Все права защищены.<br>
<a href="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/"><img src="https://www.free-kassa.ru/img/fk_btn/14.png"></a></div>
</div>

      <div class="col-sm-7">
          <ul>
			<li><a href="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/">О нас</a></li>
			<li><a href="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/">Гарантии</a></li>
			<li><a target="_blank" href="https://off-bot.ru/threads/sliv-skripta-magazina-kotdev-na-xosting.577/">Отзывы</a></li>
		
          </ul>
      </div>

</div>
</div>
  
</footer>
</div>
<!-- VK Widget -->
<div id="vk_community_messages"></div>
<script type="text/javascript">
VK.Widgets.CommunityMessages("vk_community_messages", <?=$group_id?>, {tooltipButtonText: "Есть вопрос?"});
</script>
<!-- Modal "ADD" -->
<div class="modal fade" id="open_it" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Покупка товара</h5>
        <button type="button" class="close" data-dismiss="modal" id="close_add" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div class="thumbnail">
<img id="sel_img" src="https://sun9-72.userapi.com/c855624/v855624510/1e3822/LXCykAglz6s.jpg" class="game-preview">
<div class="caption">
<p class="game-name" id="sel_name">Nvuti</p>
<p class="game-type" id="sel_desc"><img src="/img/icon.png" class="game-activate-icon"> Сервис мгновенных игр</p>
<p><span class="game-name" id="sel_cost">150 руб.</span></p>
</div>
</div>
      </div>
     
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
        <button type="button" class="btn btn-primary" id="confirm" onclick="buy()" >Купить</button>
      </div>
    </div>
  </div>
</div>
<!-- MODAL "PURCHASES" -->
<div class="modal fade" id="purchases" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Мои покупки</h5>
        <button type="button" class="close" data-dismiss="modal"  aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <table  class="table-responsive-sm table table-striped- table-bordered table-hover table-checkable">
  <thead>
    <tr>
      <th scope="col">ID покупки</th>
      <th scope="col">Название</th>
      <th scope="col">Купленный товар</th>
      
    </tr>
  </thead>
  <tbody id="purchase">
      
    <?php 
while($row = mysql_fetch_array($all_purchases)) {
 
$id = $row['id'];
$name = $row['name'];
$tovar = $row['tovar'];
echo '<tr>
      <th scope="row">'.$id.'</th>
      <td>'.$name.'</td>
      <td>'.$tovar.'</td>
    </tr>';

  }
?>

 </tbody>
 </table>
      </div>
     
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
       
      </div>
    </div>
  </div>
</div>
<!-- MODAL "DEPOSIT" -->
<div class="modal fade" id="deposit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Пополнение счета</h5>
        <button type="button" class="close" data-dismiss="modal"  aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       

    <div class="form-group">
    <label for="tovar_name">Сумма пополнения</label>
    <input type="text" class="form-control col-12" id="deposit_size" style="width:100%;"placeholder="Сумма">
  </div>

 
      </div>
     
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
         <button type="button" class="btn btn-primary" onclick="deposit()">Пополнить</button>
      </div>
    </div>
  </div>
</div>
<!-- MODAL "GARANT" -->
<div class="modal fade" id="garant" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Гарантии успешной сделки</h5>
        <button type="button" class="close" data-dismiss="modal" id="close_add" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <center>
<p><h5>Техническая поддержка</h5>
В магазине работает техническая поддержка, которая оперативно ответит на все ваши вопросы.
<a href="<?=$support?>" target="_blank">Поддержка</a></p>

<p>
<h5>Отзывы клиентов</h5>
Мы имеем положительные отзывы, оставленные покупателями после оплаты товара.
<a href="<?=$reviews?>" target="_blank">Посмотреть отзывы </a></p>
       </center>
      </div>
     
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>

<!-- MODAL "CONTACT" -->
<div class="modal fade" id="contact" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Контакты</h5>
        <button type="button" class="close" data-dismiss="modal" id="close_add" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <center>
<p><h5><i class="fab fa-vk"></i> Вконтакте</h5>
Группа - <a href="<?=$support?>" target="_blank"><?=$support?></a><br>
Поддержка - <a href="<?=$support?>" target="_blank"><?=$support?></a></p>
<p> <h5><i class="fab fa-google"></i> Почта</h5>
<a href="mailto:kotdevofficial@gmail.com" target="_blank">kotdevofficial@gmail.com</a></p>
       </center>
      </div>
     
      <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>
<script src="../js/script.js"></script>
<script src="../js/toastr.js"></script>
</body>
</html>