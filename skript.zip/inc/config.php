<?php
require("bd.php");
$admin_log = "123"; // логин админа
$admin_pass = "123"; // пароль админа
$sitename = "KotDev"; // название сайта
$sitedomen = "fun"; // домен сайта
$fk_id = 189037; // id мерчанта
$fk_secret_1 = "uuzhn2pf";
$fk_secret_2 = "uuzhn2pf";
$group_id = "192337402";
$support = "https://vk.com/id321223555"; // поддержка
$reviews = "https://vk.com/middle_dev?w=wall321223555_3690"; // отзывы
?>