<?php
session_start();
require("inc/config.php");

if($_SESSION['logged'] != '') {
  header('Location: /');
}

$s = file_get_contents('https://ulogin.ru/token.php?token=' . $_POST['token'] . '&host=' . $_SERVER['HTTP_HOST']);
$user = json_decode($s, true);
$user['network']; // соц. сеть, через которую авторизовался пользователь
$user['identity']; // уникальная строка определяющая конкретного пользователя соц. сети
$user['first_name']; // имя пользователя
$user['last_name']; // фамилия пользователя
$user['photo_big']; // фото пользователя
$network = $user['network'];
$firstname = $user['first_name'];
$lastname = $user['last_name'];
$name = "$firstname $lastname";
$ava = $user['photo_big'];
$hashq = $user['identity'];

$sql_select2 = "SELECT COUNT(*) FROM users WHERE hash='$hashq'";
$result2 = mysql_query($sql_select2);
$row = mysql_fetch_array($result2);
if($row)
{	
$logc = $row['COUNT(*)'];
}
    
        if($logc == 0) {
        if($hashq != '') {
            $_SESSION['login'] = 1;
			$insert_sql1 = "INSERT INTO `users` (`id`, `login`, `ava`, `balance`, `hash`) VALUES (NULL, '$name', '$ava', '0', '$hashq');";
mysql_query($insert_sql1);
			$_SESSION['logged'] = $hashq;
			$_SESSION['login'] = 1;
			header('Location: /');
    
        }
        }
       if($logc == 1) {
         if($hashq != '') {
         $selecter = "SELECT * FROM users WHERE hash = '$hashq'";
         $result3 = mysql_query($selecter);
         $row1 = mysql_fetch_array($result3);
		 if($row1)
		{	
		$hashlog = $row1['hash'];
         
		}
         
          $_SESSION['logged'] = $hashlog;
           $_SESSION['login'] = 1;
          
            header('Location: /');
       }
       }
  ?>